Website URL:
http://www.personal.leeds.ac.uk/~gy16jarp/webGIS/Assessment%203/index.html

Documentation for JavaScript produced with JSDoc and found in the js folder.